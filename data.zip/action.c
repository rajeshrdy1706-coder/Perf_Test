Action()
{

	lr_start_transaction("Launch Application");

	return 0;
}